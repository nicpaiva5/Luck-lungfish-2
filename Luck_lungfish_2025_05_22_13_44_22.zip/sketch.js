let trees = [];
let temperature = 30; // Temperatura inicial
let farmer;

function setup() {
  createCanvas(800, 600);
  farmer = new Farmer();
}

function draw() {
  background(135, 206, 250); // Céu azul
  fill(255, 0, 0);
  textSize(20);
  text("Temperatura: " + temperature.toFixed(1) + "°C", 20, 30);

  farmer.display();
  farmer.move();

  for (let tree of trees) {
    tree.display();
  }
}

function mousePressed() {
  trees.push(new Tree(mouseX,mouseY));
  temperature -= 0.1; // Cada árvore reduz a temperatura
}

class Farmer {
  constructor() {
    this.x = width / 2;
    this.y = height - 50;
  }

  display() {
    fill(139, 69, 19); // Marrom
    rect(this.x, this.y, 40, 40);
  }

  move() {
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= 5;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += 5;
    }
    if (keyIsDown(UP_ARROW)) {
      this.y -= 5;
    }
      if (keyIsDown(DOWN_ARROW)) {
      this.y += 5;
    }
  }
}

class Tree {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }

  display() {
    fill(34, 139, 34); // Verde
    ellipse(this.x, this.y, 40, 60);
  }
}
